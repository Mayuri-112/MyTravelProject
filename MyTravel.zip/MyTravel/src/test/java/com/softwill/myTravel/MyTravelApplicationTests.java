package com.softwill.myTravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyTravelApplicationTests {

	@Test
	void contextLoads() {
	}

}
