package com.softwill.myTravel.service;

import com.softwill.myTravel.model.User;
import com.softwill.myTravel.repository.EmailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmailService
{

	@Autowired
	private EmailRepository emailRepository;

	@Autowired
	JavaMailSender javaMailSender;

	@Value("$(spring.mail.host)")
	private String sendFrom;
	public void  saveEmail(User user){

    emailRepository.save(user);

	}

	public Optional<User> findMail(Long Id){

		return emailRepository.findById(Id);

	}

	public void sendMailToUser(String mail){

		SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
		simpleMailMessage.setFrom(sendFrom);
		simpleMailMessage.setSubject("Thanks For Subscribing MyTravel");
		simpleMailMessage.setText("Thanks for joining  MyTravel. We are happy to have you on board :-) ");
		simpleMailMessage.setTo(mail);
		javaMailSender.send(simpleMailMessage);
		sendMailToAdmin(mail);
	}

	public void sendMailToAdmin(String mail){

		SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
		simpleMailMessage.setFrom(sendFrom);
		simpleMailMessage.setSubject("Congrats, One More Added!!!");
		simpleMailMessage.setText("You have got one more subscriber :-)" + mail);
		simpleMailMessage.setTo("Admin_Email");
		javaMailSender.send(simpleMailMessage);
	}


}
