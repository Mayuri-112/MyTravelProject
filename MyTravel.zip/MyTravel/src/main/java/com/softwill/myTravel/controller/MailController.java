package com.softwill.myTravel.controller;

import com.softwill.myTravel.model.User;
import com.softwill.myTravel.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/")
public class MailController
{

	@Autowired
	EmailService emailService;

	@PostMapping("saveMail")
	public String savemail(@RequestBody User user)
	{
		emailService.saveEmail(user);
		return "Data Saved Succusefully";
	}

	@GetMapping("saveMail/{id}")
	public Optional<User> findmail(@PathVariable("id") Long id)
	{
		Optional<User> mt = emailService.findMail(id);
		return mt;
	}

	@PostMapping("register")
	public String registerUser(@RequestBody User user)
	{

		emailService.sendMailToUser(user.getEmail_id());

		return "Registered Successfully";
	}
}
